  	var custom_data = {};
	
	chrome.storage.sync.set({'user':''});
	chrome.storage.sync.set({'facial_app':false});
	
	chrome.runtime.onMessage.addListener(function(message, sender, send_response) {
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
			chrome.tabs.sendMessage(tabs[0].id, message);  
		});
	});	
	
	// Listen for port messages
	chrome.runtime.onConnect.addListener(function(port) {
		var sender = port.sender
		port.onMessage.addListener(function(message) {
			console.log('start attaching');
			// get-form-data --- To send form data to script
			if (message.type == 'get-form-data') {
				port.postMessage({'data': custom_data})
			}
		})
	})