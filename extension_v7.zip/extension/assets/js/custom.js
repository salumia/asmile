var baseUrl = 'https://www.eliteexpert.net/asmile';
var apiBaseUrl = baseUrl+'/api/public/index.php/api/';
var publicUrl = baseUrl + '/api/public/';

$('body').bind('DOMSubtreeModified', function(e) {
  if (e.target.innerHTML.length > 0) {
		var height = $(".tabs").outerHeight(true);
		$('body').height(height); 
		$('html').height(height); 
  }
});

$(document).ready(function() {
	
	$( "input" ).on("keypress",function() {
	  $(this).trigger('click');
	});	
	
	dashboard();
	
	/********* To show login form *******/
	$(document).on('change',"#selected_subject", function(){	
		if($("#app_toggle").prop("checked") == true && $(this).val() == ""){	
			message_animation('alert-danger');
			$('.msg').text("Subject must be selected when application is running.");	
			chrome.storage.sync.get(["selected_subject"], function(result){
				$("#selected_subject").val(result.selected_subject);
			})
		} else {
			chrome.storage.sync.set({'selected_subject':$(this).val()});
		}
	});
	
	/********* To show login form *******/
	$(".login-link").on('click', function(){		
		$(".initial-tabs").hide();
		$(".Login").show();
	});	
	
	/********* To show forgot password form *******/
	$("#forgot-pass-link").on('click', function(){
		$(".initial-tabs ").hide();
		$(".forgot_password").show();
	});
	
	/********* Login Toggle Password Field *******/
	$("#login_form .eye").on('click', function(){
		$("#login_form .eye").show();
		$(this).hide();
		if($(this).hasClass('show')){			
			$("#login_form input.pass").attr('type','text');
		} else {
			$("#login_form input.pass").attr('type','password');
		}
	});

	/********* To Open LinkedIn Share Feed *******/
	$("#app_toggle").on('click', function(){
		if($(this).prop("checked") == true){			
			if($("#selected_subject").val() == ""){
				$("#app_toggle").removeAttr("checked");
				message_animation('alert-danger');
				$('.msg').text("Please select subject first");				
			} else {				
				chrome.storage.sync.set({'facial_app':true});	
				chrome.runtime.sendMessage({'facial_app':'start'});
			}			
		}else if($(this).prop("checked") == false){			
			chrome.storage.sync.set({'facial_app':false});
			chrome.runtime.sendMessage({'facial_app':'stop'});
		}
		
	});
	
	/********* Logout from extension *******/
	$("#logout-link").on('click', function(){
		chrome.storage.sync.set({'user':''});		
		chrome.storage.sync.set({'facial_app':false});		
		$('.tabs').hide();
		$('#tab1').show();
		message_animation('alert-success');
		$('.msg').text('You are now logged out');
		chrome.runtime.sendMessage({'facial_app':'stop'});
	});
	
	/********* Validate login form *******/
	$("#login_form").validate({
		rules: {
			email: {
				required:true,
				email:true
			},
			password: "required",
		},
		messages: {
			email: {
				required:"Email can not be empty",
				email:"Please enter valid email"
			},
			password: "Password can not be empty",
		},
		errorPlacement: function (error, element) {
			error.insertAfter($(element).parents('label'));
		},
		submitHandler: function() {
			login();
			return false;
		}
	});
	
	/********* Validate forgot password form *******/
	$("#forgot_password_form").validate({
		rules: {
			email: {
				required:true,
				email:true,
				//remote: apiBaseUrl+"?action=isEmailRegistered"
			}
		},
		messages: {
			email: {
				required:"Email can not be empty",
				email:"Please enter valid email",
				//remote: "Email not registered with us"
			}
		},
		errorPlacement: function (error, element) {
			error.insertAfter($(element).parents('label'));
		},
		submitHandler: function() {
			forgot_password();
			return false;
		}
	});	
})

/********* To check for login from database and show their respective messages *******/
function login(){
	$.ajax({
		  type: "POST",
		  url: apiBaseUrl+"login-student",
		  data: $( "#login_form" ).serialize(),
		  dataType: 'json'
		}).done(function( response ) {
			message_animation('alert-success');
			chrome.storage.sync.set({'user':response.data});
			$('.msg').text("You are logged in successfully");
			dashboard();
		}).fail(function (xhr, exception) {
			message_animation('alert-danger');
			$('.msg').text(xhr.responseJSON.message);
		});
}

/********* To send reset password link*******/
function forgot_password(){
	
}

/********* To show response messages with animation *******/
function message_animation(addClass){
	$('.msg').addClass("alert "+ addClass);	
	setTimeout(function(){
		$('.msg').removeClass("alert alert-danger alert-success");
		$('.msg').text('');
		adjustPopUpHeight();
	}, 2000);
}

function adjustPopUpHeight(){
	var height = $(".tabs").outerHeight(true);
	$('body').height(height); 
	$('html').height(height);
}

/********* To update the extension popup pages *******/
function dashboard(){
	createSubjectsDropDown();
	chrome.storage.sync.get(["user","facial_app"], function(result){
		if(typeof result.facial_app != "undefined"){
			if(result.facial_app){
				$("#app_toggle").prop("checked", true);
			}
		}
		if(typeof result.user.id != "undefined"){
			$('.tabs').hide();
			$('#tab2').show();
			$("#head-name").text(result.user.name);
			if(result.user.profile != "" && result.user.profile != null){
				$(".profile-pic").attr("src",publicUrl+"users/"+result.user.profile);
			}
			$(".userId").val(result.user.id);
		}
	});
}

function createSubjectsDropDown(selected){
	chrome.storage.sync.get(["user","selected_subject"], function(result){
		var options = "<option value=''>Select Subject</option>";
		$.each(result.user.subjects, function( index, subject ) {
			options += "<option value='"+subject.get_subject_data.id+"'";
			if(result.selected_subject == subject.get_subject_data.id){
				options += " selected ";
			}
			options += ">"+subject.get_subject_data.name+"</option>";
		});
		$("#selected_subject").html(options);
		
	});
}


