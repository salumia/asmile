var baseUrl = 'https://www.eliteexpert.net/asmile';
var apiBaseUrl = baseUrl+'/api/public/index.php/api/';

var recording = [];
var attention_flag = true;
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
	if(msg.facial_app == "start"){
		sendWebsiteName("start")
		startApplication();
	} 
	if(msg.facial_app == "stop"){
		$("#stop").trigger('click');
		endApplication();
	}	
});	

function sendWebsiteName( flag ) {
  let name;
  if( flag === 'start' ){
    name = window.location.hostname
  } 
  if( flag === 'end' ) {
    name = ''
  }
  chrome.runtime.sendMessage({
    websiteName: name
  });
  chrome.storage.sync.set({websiteName: name});
}

function startApplication() {
	recording = [];
  try {
    let extension = document.querySelector('#ext_wrapper')
    if( !extension ) {
      appendAffedex() // installs affdex script
      $('body').prepend(code)
      addFunctionality() // all the logic for the extension
      $('#ext_wrapper').draggable()
      
    }
  } catch (error) {
    console.log('error on starting the app ', error)
  }
}

function endApplication() {
	console.log('End Application')
	$('#ext_wrapper').remove();
	sendSessionData();
}

// expressions.attention
let code = `<div id="ext_wrapper" style="">
    <div class="row">
      <div class="col-md-8" id="affdex_elements" >
      <div id="ext_canvas_placeholder" class="ext_canvas">canvas</div>
      </div>
      <div class="col-md-4">
        <div >
          <strong>EMOTION TRACKING RESULTS</strong>
          <div id="results" style="word-wrap:break-word;">Nothing yet</div>
        </div>
        <div style=" "><canvas width="300" height="200" id="myChart"></canvas></div>
		<div class="cmd-box">
			<div class="cmd">
				<strong>DETECTOR LOG MSGS</strong>
			</div>
			<div id="logs" class="cmd">Nothing yet</div>
		</div>
      </div>
    </div>
    <div>
      <button id="start" >Start</button>
      <button id="stop" style="display:none;">Stop</button>
      <button id="close" style="float:right;">Close</button>
    </div>
</div>`

var myChart;

function loadChart() {
  var ctx = document.getElementById('myChart').getContext("2d");
  let datas = {
    labels: main_object.datas.time,
    data: main_object.datas.data
  }
  myChart = new Chart(ctx, {
      type: 'line',
      data: {
          labels: datas.labels,
          datasets: [{
              label: "",
              borderColor: "#80b6f4",
              pointBorderColor: "#80b6f4",
              pointBackgroundColor: "#80b6f4",
              pointHoverBackgroundColor: "#80b6f4",
              pointHoverBorderColor: "#80b6f4",
              pointBorderWidth: 10,
              pointHoverRadius: 10,
              pointHoverBorderWidth: 1,
              pointRadius: 1,
              fill: false,
              borderWidth: 2,
              data: datas.data
          }]
      },
      options: {
         /*  legend: {
              position: "bottom"
          }, */
		  legend: { display: false },
          scales: {
              yAxes: [{
                  ticks: {
                      fontColor: "rgba(0,0,0,0.5)",
                      fontStyle: "bold",
                      beginAtZero: true,
                      maxTicksLimit: 5,
                      padding: 10
                  },
                  gridLines: {
                      drawTicks: false,
                      display: false
                  }
  
              }],
              xAxes: [{
                  gridLines: {
                      zeroLineColor: "transparent"
                  },
                  ticks: {
                      padding: 10,
                      fontColor: "rgba(0,0,0,0.5)",
                      fontStyle: "bold"
                  }
              }]
          }
      }
  });
  
}

function appendAffedex() {
  var s = document.createElement("script");
  s.type = "text/javascript";
  //s.src = "https://asmile.online/test/static/affdex.js";
  s.src = "https://eliteexpert.net/test/static/affdex.js";
  $("head").append(s);  
}

var main_object = {
  attention: 0,
  engage_status: false,
  isRunning: false,
  datas: {
    time: [],
    data: []
  }
}

function addFunctionality() {
  // load the graph
  loadChart()
  
  // SDK Needs to create video and canvas nodes in the DOM in order to function
  // Here we are adding those nodes a predefined div.
  var divRoot = $("#affdex_elements")[0];
  var width = 197;
  var height = 154;
  var faceMode = affdex.FaceDetectorMode.LARGE_FACES;
  //Construct a CameraDetector and specify the image width / height and face detector mode.
  var detector = new affdex.CameraDetector(divRoot, width, height, faceMode);

  //Enable detection of all Expressions, Emotions and Emojis classifiers.
  detector.detectAllExpressions();

  //Add a callback to notify when the detector is initialized and ready for runing.
  detector.addEventListener("onInitializeSuccess", function () {
    main_object.isRunning = true;

    log('#logs', "Application has started.");
    //Display canvas instead of video feed because we want to draw the feature points on it
    $("#face_video_canvas").css("display", "block").addClass('ext_canvas')
    $("#face_video").css("display", "none");
    $("#ext_canvas_placeholder").css("display", "none")

  });

  function log(node_name, msg) {
    $(node_name).html("<span>" + msg + "</span><br />")
  }

  //function executes when Start button is pushed.
  function onStart() {
    if (detector && !detector.isRunning) {
      $("#logs").html("");
      detector.start();
	  $('#start').toggle();
	  $('#stop').toggle();
	  $('#close').toggle();
    }
    log('#logs', "Starting the application. Please wait...");
  }
  
  $('#start').click(onStart)
  //function executes when the Stop button is pushed.
	function onStop() {
		$("#ext_canvas_placeholder").css("display", "block")

		log('#logs', "Application has stopped.");
		if (detector && detector.isRunning) {
			detector.removeEventListener();
			detector.stop();
		}
	};
  
  $('#stop').on("click",function(){
	  onStop();
	  sendSessionData();
	  $('#start').toggle();
	  $('#stop').toggle();
	  $('#close').toggle();
  });
  
  $('#close').on("click",function(){
		onStop();		
	  	console.log('End Application')
		$('#ext_wrapper').remove();
		sendSessionData();
  });

  //Add a callback to notify when camera access is allowed
  detector.addEventListener("onWebcamConnectSuccess", function () {
    $("#face_video").css("display", "none");

    log('#logs', "Webcam access allowed. Please wait...");
  });

  //Add a callback to notify when camera access is denied
  detector.addEventListener("onWebcamConnectFailure", function () {
    log('#logs', "webcam denied");
  });

  //Add a callback to notify when detector is stopped
  detector.addEventListener("onStopSuccess", function () {
    main_object.isRunning = false;

    log('#logs', "The detector reports stopped.");
    $("#ext_canvas_placeholder").css("display", "block")
    $("#results").html("Nothing yet");
  });

  //Add a callback to receive the results from processing an image.
  //The faces object contains the list of the faces detected in an image.
  //Faces object contains probabilities for all the different expressions, emotions and appearance metrics
  detector.addEventListener("onImageResultsSuccess", function (faces, image, timestamp) {
    //$('#results').html("");
    if (faces.length > 0) {	
		if(attention_flag){
		  attention_flag = false;
		  main_object.engage_status = true
		  main_object.attention = faces[0].expressions.attention
		  // push into the list the current date and current affection
		  

		  if( main_object.datas.data.length > 10 ) {
			main_object.datas.data.shift()
			main_object.datas.time.shift()

			main_object.datas.data.push( faces[0].expressions.attention )
			main_object.datas.time.push( "" )

			myChart.update()
		  } else {
			main_object.datas.data.push( faces[0].expressions.attention )
			main_object.datas.time.push( "" )

			myChart.update()
		  }
		
		  log('#results', "Attention: " + JSON.stringify(faces[0].expressions.attention, function (key, val) {
			return val.toFixed ? Number(val.toFixed(0)) : val;
		  }));
		
		}
      if($('#face_video_canvas')[0] != null) {
        drawFeaturePoints(image, faces[0].featurePoints);
      } 
    } else {
      log('#results', "Attention: 0")
      main_object.engage_status = false
      main_object.attention = 0
    }
  });

  //Draw the detected facial feature points on the image
  // Currently not in use!!!
  function drawFeaturePoints(img, featurePoints) {
    var contxt = $('#face_video_canvas')[0].getContext('2d');

    // contxt.setAttribute('class', 'ext_canvas')
    var hRatio = contxt.canvas.width / img.width;
    var vRatio = contxt.canvas.height / img.height;
    var ratio = Math.min(hRatio, vRatio);

    contxt.strokeStyle = "#FFFFFF";
    for (var id in featurePoints) {
      contxt.beginPath();
      contxt.arc(featurePoints[id].x,
      featurePoints[id].y, 2, 0, 2 * Math.PI);
      contxt.stroke();

    }
  }

	// Alert user when not there is attention < 50
	setInterval(function(){
		if((main_object.attention < 50) && main_object.isRunning ){
			alert("Your attention is less than 50%. Please concentrate more");
		}
	} , 4000);
  
	setInterval(function(){
		if(main_object.isRunning){
			recording.push(JSON.stringify(main_object.attention, function (key, val) {
				return val.toFixed ? Number(val.toFixed(0)) : val;
			}));
		}
	} , 3000);
	
	setInterval(function(){
		attention_flag = true;
	} , 1000);
	
}

function sendSessionData(){		
	if(recording.length > 0){
		chrome.storage.sync.set({recording:recording});
		recording = [];
		chrome.storage.sync.get(["user","selected_subject","recording"], function(result){
			if(result.selected_subject.length > 0){
				var student_id = result.user.id;	
				var subject_id = result.selected_subject;	
				var data = result.recording;	
				var input = {student_id:student_id,subject_id:subject_id,data:JSON.stringify(data), page_url: window.location.href};
				$.ajax({
				  type: "POST",
				  url: apiBaseUrl+"attention-log",
				  data: input,
				  dataType: 'json'
				}).done(function( response ) {
					//console.log(response);
				}).fail(function (xhr, exception) {
					//console.log(xhr);
				});
			}
		});
	}
}