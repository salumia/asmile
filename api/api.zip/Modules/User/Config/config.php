<?php

return [
    'name' => 'User'
];
