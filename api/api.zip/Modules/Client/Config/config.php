<?php

return [
    'name' => 'Client'
];
