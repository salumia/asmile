<?php

namespace Modules\Client\Entities;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
	protected $table = 'users';
	protected $fillable = [];
}
