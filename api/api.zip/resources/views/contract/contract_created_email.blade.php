<p>Name: {{ $name }}</p>
<p>E-Mail: {{ $email }}</p>
<p>Subject: {{ $title }}</p>
<p>Message: <br>
{{ $content }}</p>