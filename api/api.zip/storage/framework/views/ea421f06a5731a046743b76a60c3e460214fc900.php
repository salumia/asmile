<p>Name: <?php echo e($name); ?></p>
<p>E-Mail: <?php echo e($email); ?></p>
<p>Subject: <?php echo e($title); ?></p>
<p>Message: <br>
<?php echo e($content); ?></p>