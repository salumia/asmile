<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Set\\Providers\\SetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Set\\Providers\\SetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);