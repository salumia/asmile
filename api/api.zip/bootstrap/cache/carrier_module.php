<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Carrier\\Providers\\CarrierServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Carrier\\Providers\\CarrierServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);