<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SC\\Providers\\SCServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SC\\Providers\\SCServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);