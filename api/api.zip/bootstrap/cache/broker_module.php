<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Broker\\Providers\\BrokerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Broker\\Providers\\BrokerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);