<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Agency\\Providers\\AgencyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Agency\\Providers\\AgencyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);