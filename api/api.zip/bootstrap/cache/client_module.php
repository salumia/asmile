<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Client\\Providers\\ClientServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Client\\Providers\\ClientServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);