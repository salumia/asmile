<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Appraisal\\Providers\\AppraisalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Appraisal\\Providers\\AppraisalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);