<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Claim\\Providers\\ClaimServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Claim\\Providers\\ClaimServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);