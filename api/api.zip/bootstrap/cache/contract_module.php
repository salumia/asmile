<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contract\\Providers\\ContractServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contract\\Providers\\ContractServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);