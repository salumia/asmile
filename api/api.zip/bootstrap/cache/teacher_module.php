<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Teacher\\Providers\\TeacherServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Teacher\\Providers\\TeacherServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);