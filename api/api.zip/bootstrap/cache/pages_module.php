<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pages\\Providers\\PagesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pages\\Providers\\PagesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);