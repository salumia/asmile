<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DocumentQueues\\Providers\\DocumentQueuesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DocumentQueues\\Providers\\DocumentQueuesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);